<?php
	// $servername = "172.16.0.143";
	// $username = "user_test";
	// $password = "[isd2018*W0w]";
	// $database = "db_grs";
	// $cookie_name = "";
	// $cookie_value = "";
	
	$servername = "grs.balaiisabel.com";
	$username = "balaiisa_grs";
	$password = "[isd2019*W0w]";
	$database = "balaiisa_db_grs";
?>