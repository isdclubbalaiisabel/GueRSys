
<?php

	include "configs/connect_database.php";

	if(!isset($_COOKIE["room_code"])) {
	
		header("location:set_room_code.php");
	}
	
	//echo $_COOKIE["room_code"];
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="http://www.thesoftwareguy.in/favicon.ico" type="image/x-icon" />
    <meta name="author" content="Shahrukh Khan">
    <meta name="description" content="Login System with Github using OAuth PHP and MySQL">
    <meta name="keywords" content="php,mysql,Github,oauth,social logins,thesoftwareguy">
    <meta name="title" content="Login System with Github using OAuth PHP and MySQL">

    <title> a</title>

    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="bootstrap/css/font-awesome.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="bootstrap/html5shiv.js"></script>
      <script src="bootstrap/respond.min.js"></script>
    <![endif]-->

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="bootstrap/js/jquery-1.11.1.min.js"></script>
	
<style>
  ul#stepForm, ul#stepForm li {
    margin: 0;
    padding: 0;
  }
  ul#stepForm li {
    list-style: none outside none;
  } 
  label{margin-top: 10px;}
  .help-inline-error{color:red;}
</style>
  </head>
  <body>

<div class="container" >
  <div class="panel panel-primary">
    <div class="panel-heading">
     
    </div>
    <div class="panel-body">
      <form name="basicform" id="basicform" method="post" action="yourpage.html">
        
       <div id="sf3" class="frm" >
          <fieldset>
            <div class="form-group">
              <div class="col-lg-12">
                <a class="btn btn-primary" href = "index2.php">New Request </a> 
                <img src="spinner.gif" alt="" id="loader" style="display: none">
              </div>
            </div>
			<div class="clearfix" style="height: 10px;clear: both;"></div>
            <div class="form-group">

              <div class="col-lg-12" id = "all_my_requests">
               
              </div>
            </div>
            
          </fieldset>
        </div>
      </form>
    </div>
  </div>


</div>
<script type="text/javascript" src="jquery.validate.js"></script>

<script src="bootstrap/js/bootstrap.min.js"></script>
<script>
	$(document).ready(function (e) {

		setInterval(function()
		{ 
			$.ajax( {
			url: "ajax/refresh_rqs.php?id=" + $('#concern_cats').val(), 
			dataType: "text",
			success: function(strMessage) {

				$("#all_my_requests").html(strMessage);
					
				
				}
			});
		}, 1000);
	});
	
</script>
</body>
</html>